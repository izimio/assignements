javac *.java
java ParkingSemaphore